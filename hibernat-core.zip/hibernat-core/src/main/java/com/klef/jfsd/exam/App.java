package com.klef.jfsd.exam;

public class App {

    public static void main(String[] args) {
        ClientDemo clientDemo = new ClientDemo();
        clientDemo.run1();
    }
}